<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h3>Recuperação de Senha</h3>
        <p>Usuário: {{$login}}, sua senha foi alterada para: {{$senha}}</p>
    </body>
</html>
